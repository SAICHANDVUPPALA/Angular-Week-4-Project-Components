
import {Component} from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'project';
  opened=false;
  componentslist=["Typography","Button","ToggleButton","Icon","Badges","Progress Spinner","Navbar","Sidenav","Menu bar","List Items","Grid List",
  "Panel","Cards","Tabs","Stepper","Input","Select","Autocomplete","Checkbox","RadioButton","Date Picker","Tooltip","Snackbar","Dialog",
  "Data table"];

}
