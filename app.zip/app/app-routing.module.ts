import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {TypographyComponent} from './typography/typography.component'
import {ButtonComponent} from './button/button.component'
import {AutocompleteComponent} from './autocomplete/autocomplete.component'
import {BadgesComponent} from './badges/badges.component'
import {CardsComponent} from './cards/cards.component'
import {CheckboxComponent} from './checkbox/checkbox.component'
import {DatatableComponent} from './datatable/datatable.component'
import {DatepickerComponent} from './datepicker/datepicker.component'
import {DialogComponent} from './dialog/dialog.component'
import {GridListComponent} from './grid-list/grid-list.component'
import {IconComponent} from './icon/icon.component'
import {InputComponent} from './input/input.component'
import {ListItemsComponent} from './list-items/list-items.component'
import {MenubarComponent} from './menubar/menubar.component'
import {NavbarComponent} from './navbar/navbar.component'
import {PanelComponent} from './panel/panel.component'
import {ProgressSpinnerComponent} from './progress-spinner/progress-spinner.component'
import {RadiobuttonComponent} from './radiobutton/radiobutton.component'
import {SelectComponent} from './select/select.component'
import {SidenavComponent} from './sidenav/sidenav.component'
import {SnackbarComponent} from './snackbar/snackbar.component'
import {StepperComponent} from './stepper/stepper.component'
import {TabsComponent} from './tabs/tabs.component'
import {ToggleButtonComponent} from './toggle-button/toggle-button.component'
import {TooltipComponent} from './tooltip/tooltip.component'

const routes: Routes = [{path:'Typography',component: TypographyComponent},{path:'Button',component: ButtonComponent},
{path:"ToggleButton",component:ToggleButtonComponent},{path:"Icon",component:IconComponent},{path:"Badges",component:BadgesComponent},
{path:"Progress Spinner",component:ProgressSpinnerComponent},{path:"Navbar",component:NavbarComponent},{path:"Sidenav",component:SidenavComponent},
{path:"Menu bar",component:MenubarComponent},{path:"List Items",component:ListItemsComponent},{path:"Grid List",component:GridListComponent},
{path:"Panel",component:PanelComponent},{path:"Cards",component:CardsComponent},{path:"Tabs",component:TabsComponent},
{path:"Stepper",component:StepperComponent},{path:"Input",component:InputComponent},{path:"Select",component:SelectComponent},
{path:"Autocomplete",component:AutocompleteComponent},{path:"Checkbox",component:CheckboxComponent},{path:"RadioButton",component:RadiobuttonComponent},
{path:"Date Picker",component:DatepickerComponent},{path:"Tooltip",component:TooltipComponent},{path:"Snackbar",component:SnackbarComponent},
{path:"Dialog",component:DialogComponent},{path:"Data table",component:DatatableComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
